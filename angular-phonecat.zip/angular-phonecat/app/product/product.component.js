angular.
    module('app').
    component('productComponent', {
        template: '<product-component></product-component>'
    }
        
);
app.controller('product', function ($scope, $http, $state,$rootScope) {
    $rootScope.userName = window.localStorage.getItem("SessionName");
    $http.get('https://62df63fe9c47ff309e853ae1.mockapi.io/api/products')
       
        .then(function (response) {
            $scope.productdata;
            productdata = response.data;
            console.log(productdata);
            function cardgroup(arr, size) {
                var myarr = [];
                for (let i = 0; i < arr.length; i+=size){
                    myarr.push(arr.slice(i, i + size));
                }
                return myarr;
            }
            $scope.productdata = cardgroup(productdata, 3);
    })
   
    $scope.buyNow = function (id) {
        console.log(id);
        $state.go('product-details', { id: id });
        
    }
  });
  
    