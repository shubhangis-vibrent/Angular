
app.controller('allProduct', function ($scope, $http, $state) {
    
    $http.get('https://62df63fe9c47ff309e853ae1.mockapi.io/api/products')
       
        .then(function (response) {
            $scope.productdata = response.data;
            console.log( $scope.productdata);
            
    })
   
    $scope.edit = function (id,name,image,description,price) {
       
        $state.go('editUser',{id:id,name:name,image:image,description:description,price:price});
    }

    

    $scope.delete = function (id) {
        for (i in $scope.productdata) {
            if ($scope.productdata[i].id == id) {
                $http.delete('https://62df63fe9c47ff309e853ae1.mockapi.io/api/products/' + id)
                    .then(function (response) {
                        
                        alert("data deleted Successfully...!!!")
                        $scope.productdata.splice(i, 1); 
                        $scope.newproductdata= {};
                        console.log(response)
                        $state.go('allProductdata')
                    }, function (error) {
                        alert("Something Went Wrong")
                        console.log(error);
                    })
            }
        }
    }
    

  });
  
    