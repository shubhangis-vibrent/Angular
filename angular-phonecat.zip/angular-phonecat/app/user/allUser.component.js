
app.controller('allUser', function ($scope, $http, $state) {
    
    $http.get('https://62df63fe9c47ff309e853ae1.mockapi.io/api/user')
       
        .then(function (response) {
            $scope.userdata = response.data;
            console.log( $scope.userdata);
            
    })
   
    $scope.edit = function (id,name,email,address,mobile,password,repassword) {
        console.log(id, name, email, address, mobile, password, repassword);
        $state.go('editUser',{id:id,name:name,email:email,address:address,mobile:mobile,password:password,repassword:repassword});
    }

    $scope.delete = function (id) {
        for (i in $scope.userdata) {
            if ($scope.userdata[i].id == id) {
                $http.delete('https://62df63fe9c47ff309e853ae1.mockapi.io/api/user/' + id)
                    .then(function (response) {
                        
                        alert("data deleted Successfully...!!!")
                        $scope.userdata.splice(i, 1); 
                        $scope.newuserdata = {};
                        console.log(response)
                        $state.go('allUser')
                    }, function (error) {
                        alert("Something Went Wrong")
                        console.log(error);
                    })
            }
        }
    }
    // $scope.delete = function (id) {
    //     for (i in $scope.userdata) {         
    //         if ($scope.userdata[i].id == id) {        
    //            $scope.userdata.splice(i, 1);        
    //            $scope.newStudent = {};        
    //         }  
    //     }
    // }
     
    

  });
  
    