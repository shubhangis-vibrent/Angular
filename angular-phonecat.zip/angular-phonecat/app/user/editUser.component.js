
app.controller('editUser', function ($scope, $stateParams,$http,$state) {
    $scope.id = $stateParams.id;
    $scope.name = $stateParams.name;
    $scope.email= $stateParams.email;
    $scope.address= $stateParams.address;
    $scope.mobile = parseInt($stateParams.mobile);
    $scope.password= $stateParams.password;
    $scope.repassword= $stateParams.repassword;
    
    console.log($stateParams.id);
    
    $scope.editdata = function (name, email, address, mobile, password, repassword) {
        var data = {
          name: name,
          email: email,
          address: address,
          mobile: mobile,
          password: password,
          repassword: repassword
        }
        $http.put("https://62df63fe9c47ff309e853ae1.mockapi.io/api/user/"+ $scope.id, JSON.stringify(data))
          .then(function (response) {
            console.log(response);
            if (response.data) {                  
             alert("data updated Successfully...!!!")
              $state.go('allUser');
            }
          }, function (error) {
            alert("Something Went Wrong")
            console.log(error);
          })
      }
   

  });
  
    