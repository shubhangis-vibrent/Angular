angular.
    module('app').
    component('productDetail', {
        template: '<productDetail></details-component>'
    }
        
);
app.controller('product-details', function ($scope, $stateParams,$state,$http) {
    $scope.name = $stateParams.name;
    $scope.image = $stateParams.image;
    $scope.description = $stateParams.description;
    $scope.price = $stateParams.price;
 
    
    $scope.addToCart = function (name,price) {
        var data = {
            name:name,
            price: price,
            
        }
        var qty = document.getElementById('qty').value.trim();
        console.log(qty);
        var price = $scope.price * qty;

        $http.post('https://62df63fe9c47ff309e853ae1.mockapi.io/api/cart', JSON.stringify(data))
            .then(function (response){
            console.log(response.data);
        })
        console.log(price);
        $state.go('cart', { price: price});
    }
    
});