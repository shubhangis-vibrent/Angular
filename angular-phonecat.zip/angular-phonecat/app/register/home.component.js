app.controller('home', function ($rootScope) {   
     window.localStorage.clear();
     $rootScope.isUserLoggedIn = false;    
})