angular.
    module('app').
    component('registerComponent', {
        template: '<register-component></register-component>'
    }
        
);
    
app.controller('register', function ($scope,$http, $state) {
    $scope.name = null;
    $scope.email = null;
    $scope.address = null;
    $scope.mobile = null;
    $scope.password = null;
    $scope.repassword = null;

  $scope.postdata = function (name, email, address, mobile, password, repassword) {
    var data = {
      name: name,
      email: email,
      address: address,
      mobile: mobile,
      password: password,
      repassword: repassword
    }
    $http.post("https://62df63fe9c47ff309e853ae1.mockapi.io/api/user", JSON.stringify(data))
      .then(function (response) {
        console.log(response);
        if (response.data) {                  
         alert("Registration done Successfully...!!!")
          $state.go('login');
        }
      }, function (error) {
        alert("Something Went Wrong")
        console.log(error);
      })
  }
  
});