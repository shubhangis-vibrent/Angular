var finalamount=0
var result=(function counter(){ //outer function
   var c=0;
   return function increasecount(){ 
       return ++c; 
   }
})() 

document.getElementById("c1").addEventListener("click",function(){
        var quantity=document.getElementById("t1").value;
    if(quantity.length==0){ alert("plz enter qty") 
     document.getElementById("c1").checked=false;
     }else{
        var srno=document.createTextNode(result())
        var pname=document.createTextNode(document.getElementById("n1").innerHTML)
        var n=document.createTextNode(parseFloat(document.getElementById("p1").innerHTML))
        var m=document.createTextNode(parseInt(quantity))
        price=parseFloat(document.getElementById("p1").innerHTML)
        qty=parseInt(quantity)
        var total=document.createTextNode(price*qty)
        finalamount+=price*qty
        
    var tr1=document.createElement("tr")
       var td1=document.createElement("td")
        td1.appendChild(srno)
       var td2=document.createElement("td")
       td2.appendChild(pname)
       var td3=document.createElement("td")
       td3.appendChild(n)
       var td4=document.createElement("td")
       td4.appendChild(m)
       var td5=document.createElement("td")
       td5.appendChild(total)

       tr1.appendChild(td1)
       tr1.appendChild(td2)
       tr1.appendChild(td3)
       tr1.appendChild(td4)
       tr1.appendChild(td5)
   // document.body.appendChild(tr1)
       document.getElementById("list").appendChild(tr1)
      }
})   

document.getElementById("c2").addEventListener("click",function(){
        var quantity=document.getElementById("t2").value;
    if(quantity.length==0){ alert("plz enter qty") 
     document.getElementById("c2").checked=false;
     }else{
        var srno=document.createTextNode(result())
        var pname=document.createTextNode(document.getElementById("n2").innerHTML)
        var n=document.createTextNode(parseFloat(document.getElementById("p2").innerHTML))
        var m=document.createTextNode(parseInt(quantity))
        price=parseFloat(document.getElementById("p2").innerHTML)
        qty=parseInt(quantity)
        var total=document.createTextNode(price*qty)
        finalamount+=price*qty
        
    var tr1=document.createElement("tr")
       var td1=document.createElement("td")
        td1.appendChild(srno)
       var td2=document.createElement("td")
       td2.appendChild(pname)
       var td3=document.createElement("td")
       td3.appendChild(n)
       var td4=document.createElement("td")
       td4.appendChild(m)
       var td5=document.createElement("td")
       td5.appendChild(total)

       tr1.appendChild(td1)
       tr1.appendChild(td2)
       tr1.appendChild(td3)
       tr1.appendChild(td4)
       tr1.appendChild(td5)
   // document.body.appendChild(tr1)
       document.getElementById("list").appendChild(tr1)
      }
})   

document.getElementById("c3").addEventListener("click",function(){
        var quantity=document.getElementById("t3").value;
    if(quantity.length==0){ alert("plz enter qty") 
     document.getElementById("c3").checked=false;
     }else{
        var srno=document.createTextNode(result())
        var pname=document.createTextNode(document.getElementById("n3").innerHTML)
        var n=document.createTextNode(parseFloat(document.getElementById("p3").innerHTML))
        var m=document.createTextNode(parseInt(quantity))
        price=parseFloat(document.getElementById("p3").innerHTML)
        qty=parseInt(quantity)
        var total=document.createTextNode(price*qty)
        finalamount+=price*qty
        
    var tr1=document.createElement("tr")
       var td1=document.createElement("td")
        td1.appendChild(srno)
       var td2=document.createElement("td")
       td2.appendChild(pname)
       var td3=document.createElement("td")
       td3.appendChild(n)
       var td4=document.createElement("td")
       td4.appendChild(m)
       var td5=document.createElement("td")
       td5.appendChild(total)

       tr1.appendChild(td1)
       tr1.appendChild(td2)
       tr1.appendChild(td3)
       tr1.appendChild(td4)
       tr1.appendChild(td5)
   // document.body.appendChild(tr1)
       document.getElementById("list").appendChild(tr1)
      }
})   

document.getElementById("c4").addEventListener("click",function(){
        var quantity=document.getElementById("t4").value;
    if(quantity.length==0){ alert("plz enter qty") 
     document.getElementById("c4").checked=false;
     }else{
        var srno=document.createTextNode(result())
        var pname=document.createTextNode(document.getElementById("n4").innerHTML)
        var n=document.createTextNode(parseFloat(document.getElementById("p4").innerHTML))
        var m=document.createTextNode(parseInt(quantity))
        price=parseFloat(document.getElementById("p4").innerHTML)
        qty=parseInt(quantity)
        var total=document.createTextNode(price*qty)
        finalamount+=price*qty
        
    var tr1=document.createElement("tr")
       var td1=document.createElement("td")
        td1.appendChild(srno)
       var td2=document.createElement("td")
       td2.appendChild(pname)
       var td3=document.createElement("td")
       td3.appendChild(n)
       var td4=document.createElement("td")
       td4.appendChild(m)
       var td5=document.createElement("td")
       td5.appendChild(total)

       tr1.appendChild(td1)
       tr1.appendChild(td2)
       tr1.appendChild(td3)
       tr1.appendChild(td4)
       tr1.appendChild(td5)
   // document.body.appendChild(tr1)
       document.getElementById("list").appendChild(tr1)
      }
})   
  
function read(){
     
         c=0
         alert('Final Amount='+finalamount)
        }