var app = angular.module('app', ['ui.router']);

app.config(['$stateProvider', function ($stateProvider) {
 
  $stateProvider
    .state('root', {
      url: '/',
      templateUrl: 'register/register.html',
      controller: 'register'
    })
    .state('login', {
      url: '/login',
      templateUrl: 'login/login.html',
      controller: 'login'
    })
    .state('dashboard', {
      url: '/dashboard',
      templateUrl: 'dashboard/dashboard.html',
      controller: 'dashboard'
    });
  //   .state('root', {
  //   url: '/',
  //   template: '<h1>First page</h1>'
  // });
}]);



app.controller('register', function ($scope,$state) {
  $scope.sendForm = function () {
    if ($scope.patientForm.$valid) {
      const username = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const mobile = document.getElementById('mobile').value.trim();
      const dob = document.getElementById('dob').value.trim();
      const password = document.getElementById('password').value.trim();

      alert("Form submitted Successfully....!!!");
      localStorage.setItem('name', username);
      localStorage.setItem('email', email);
      localStorage.setItem('mobile', mobile);
      localStorage.setItem('dob', dob);
      localStorage.setItem('password', password);
      console.log(username, email, mobile, dob, password);
      $state.go('login');
    } else {
      alert("Something Went Wrong")
    }
    };
});


app.controller('login', function ($scope,$state) {
  $scope.sendForm = function () {
    if ($scope.loginForm.$valid) {
      const cemail = document.getElementById('email').value.trim();
      const cpassword = document.getElementById('password').value.trim();

      const email=localStorage.getItem('email');
      const password=localStorage.getItem('password');
      if (cemail == email && cpassword == password) {
        alert("Login Successfully....!!!");
        $state.go('dashboard');
      } else {
        alert("Email and Passwor doesn't match")
      }
    } else {
      alert("Something Went Wrong")
    }
    };
});


app.controller('dashboard', function ($scope,$state) {
  $scope.userName = localStorage.getItem('name');
  $scope.email = localStorage.getItem('email');
  $scope.mobile = localStorage.getItem('mobile');
  $scope.dob = localStorage.getItem('dob');

  $scope.logout = function () {
    window.localStorage.clear();
    
    $state.go("login");
};
});

