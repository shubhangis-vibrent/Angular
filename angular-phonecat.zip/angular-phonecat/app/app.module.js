var app = angular.module('app', ['ui.router']);


app.config(['$stateProvider' , function ($stateProvider) {
  $stateProvider
    .state('home', {
      url: '/',
      templateUrl: 'register/home.html',  
      controller:'home'
    })
    .state('register', {
      url: '/register',
      templateUrl: 'register/register.html',
      controller: 'register'
    })
    .state('login', {
      url: '/login',
      templateUrl: 'login/login.html',
      controller: 'login'
    })
    .state('allUser', {
      url: '/allUser',
      templateUrl: 'user/allUser.html',
      controller: 'allUser'
    })
    .state('editUser', {
      url: '/editUser/:id/:name/:email/:address/:mobile/:password/:repassword',
      templateUrl: 'user/editUser.html',
      controller: 'editUser'
    })
    // .state('editUser', {
    //   url: '/editUser',
    //   params: {
    //     id: '',name:'',email:'',address:'',mobile:'',password:'',repassword:''
    //   },
    //   templateUrl: 'user/editUser.html',
    //   controller: 'editUser'
    // })
    .state('allProduct', {
      url: '/allProduct',
      templateUrl: 'product/allProduct.html',
      controller: 'allProduct'
    }) 
    .state('dashboard', {
      url: '/dashboard',
      templateUrl: 'product/product.html',
      controller: 'product'
    })
    .state('product-details', {
      url: '/product-details/:name/:image/:description/:price',
      templateUrl: 'product-details/product-details.html',
      controller: 'product-details'
    })
    .state('cart', {
      url: '/cart',
      params:{price:''},
      templateUrl: 'cart/cart.html',
      controller: 'cart'
    })
    .state('otherwise', {
      url: '/home',
      templateUrl:'register/home.html'
    }) ;
  
}]);


