
import { createStore } from 'redux';

import rootReducer from './reducer.js';

/* eslint-disable no-underscore-dangle */

/* @ngInject */
function config($ngReduxProvider) {
    const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
    /* eslint-enable */
    const middlewares = [ ];
    const composedMiddlewares = composeEnhancers(applyMiddleware(...middlewares));
    const store = createStore(rootReducer, composedMiddlewares);
    $ngReduxProvider.provideStore(store);
}

export default config;