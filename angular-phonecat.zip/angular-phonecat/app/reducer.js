import {combineReducers} from 'redux';

import * as actions from './actions';

// export function reducer(state = initialState, action) {
//     switch (action.type) {
//     case actions.PARSE_URL_PARAMS: {
//         const {
//             taskCode,
//         } = action.payload;
//         return {
//             ...state,
//             taskCode,
//         };
//     }
//     case CHANGE_LOCALE: {
//         return {
//             ...state,
//             locale : state.lang === LANGUAGES.SPANISH.key ?
//                 LANGUAGES.ENGLISH.key :
//                 LANGUAGES.SPANISH.key,
//         };
//     }
//     case actions.GET_UNAUTHENTICATED_TASK_DETAILS_SUCCESS: {
//         const {
//             locale,
//             programCode,
//             taskDetails,
//             userTaskDetails,
//         } = action.payload;
//         return {
//             ...state,
//             locale      : locale,
//             programCode : programCode,
//             taskDetails,
//             userTaskDetails,
//         };
//     }
//     case actions.GET_UNAUTHENTICATED_TASK_DETAILS_FAILURE: {
//         return {
//             ...state,
//             taskDetails : initialState.taskDetails,
//         };
//     }
//     case actions.GET_UNAUTHENTICATED_FORM_DETAILS_SUCCESS: {
//         return {
//             ...state,
//             formDetails : action.payload,
//         };
//     }
//     case actions.GET_UNAUTHENTICATED_FORM_DETAILS_FAILURE: {
//         return {
//             ...state,
//             formDetails : initialState.formDetails,
//         };
//     }
//     default:
//         return state;
//     }
// }

export function user(state = {id : null}, action) {
    switch (action.type) {
    case actions.SET_USER: {
        return {
            ...state,
            id : action.payload,
        };
    }
    default:
        return state;
    }
}



export default combineReducers({
   
    
    user    : user,
    
});