 const RootReducer = combineReducers({
    todos: TodosReducer
});
