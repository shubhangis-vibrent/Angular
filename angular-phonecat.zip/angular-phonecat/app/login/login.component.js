angular.
    module('app').
    component('loginComponent', {
        template: '<login-component></login-component>'
    }
        
);

app.controller('login', function ($scope, $state,$rootScope, $http) {
    $rootScope.isUserLoggedIn = false;
    $scope.email;
    $scope.password;
    $scope.logindata = function () {
        var cemail = document.getElementById('email').value.trim();
        var cpassword = document.getElementById('password').value.trim();
        // console.log(cemail, cpassword);
        $http.get("https://62df63fe9c47ff309e853ae1.mockapi.io/api/user")
            .then(function (response) {
                $scope.arr;
                arr = response.data;
                // console.log(arr);
                for (let i = 0; i < arr.length; i++) {
                    if (cemail == arr[i].email && cpassword == arr[i].password) {
                        // console.log(arr[i].email, arr[i].password);
                        $scope.sessionName = arr[i].name;
                        console.log($scope.sessionName);
                        alert("Login Successfully");
                        window.localStorage.setItem("SessionName", $scope.sessionName);
                        $rootScope.isUserLoggedIn = true;
                        $state.go('dashboard');
                    }
                }
            });        
    }, function (error) {
        alert("Something Went Wrong")
        console.log(error);
    }
});
  

  
  