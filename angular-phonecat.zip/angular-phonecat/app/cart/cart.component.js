app.controller('cart', function ( $scope,$stateParams) {
    
    $scope.price = $stateParams.price;
    console.log($scope.price);
})